# Test Workspace for Localization Scanner

This is a test workspace to verify the Localization Scanner extension with **deeply nested localization keys** (5-7 levels deep).

## Expected Results

When you scan this workspace, you should find the following **missing keys**:

### Dashboard.tsx (7 missing keys)
1. `app.features.analytics.charts.users.inactive.label` (6-level deep)
2. `app.features.analytics.charts.expenses.title` (5-level deep)
3. `app.navigation.menu.items.profile.label` (4-level deep)
4. `app.features.reports.monthly.sales.summary` (5-level deep)

### profile.ts (5 missing keys)
5. `user.profile.personal.details.basic.age` (6-level deep)
6. `user.profile.personal.details.address.country` (6-level deep)
7. `user.profile.settings.privacy.options.notifications.sound.enabled` (7-level deep!)
8. `user.profile.personal.details.address.zipcode` (6-level deep)
9. `user.profile.settings.privacy.options.notifications.email.schedule.daily` (8-level deep!)

### errors.ts (10 missing keys)
10. `error.network.server.title` (5-level deep)
11. `error.network.auth.failed.message.text` (6-level deep)
12. `error.validation.fields.email.format.invalid` (6-level deep)
13. `error.validation.fields.password.strength.weak` (6-level deep)
14. `error.validation.fields.phone.format.invalid` (6-level deep)
15. `app.navigation.menu.items.reports.label` (5-level deep)
16. `app.navigation.menu.items.analytics.label` (5-level deep)
17. `app.navigation.menu.items.logout.label` (5-level deep)

**Total: ~17-18 missing keys** with varying nesting depths (4-8 levels)

## Keys that exist (should NOT be flagged):
- `app.features.analytics.charts.users.active.label` (6-level deep)
- `app.features.analytics.charts.revenue.title` (5-level deep)
- `app.navigation.menu.items.dashboard.label` (5-level deep)
- `user.profile.personal.details.basic.name` (6-level deep)
- `user.profile.personal.details.basic.email` (6-level deep)
- `user.profile.personal.details.address.street` (6-level deep)
- `error.network.timeout.title` (5-level deep)
- And more standard keys from previous tests

## How to Test

1. Press **F5** in the extension project
2. In the Extension Development Host window, this folder should already be open
3. Click the refresh button (🔄) in the Localization Scanner sidebar
4. Verify that ~17-18 missing keys are shown with deep nesting
5. Click on each key to navigate to its usage location
6. Verify the tree view correctly displays the full nested key names
