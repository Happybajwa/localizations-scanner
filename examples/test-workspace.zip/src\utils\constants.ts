// Constants file with various string types

// CASE 1: API endpoints (should be ignored - they're technical paths)
export const API_ENDPOINTS = {
    users: "/api/v1/users",
    products: "/api/v1/products",
    auth: "/api/v1/auth/login"
};

// CASE 2: HTTP headers (should be ignored - technical)
export const HTTP_HEADERS = {
    contentType: "application/json",
    accept: "application/json",
    authorization: "Bearer"
};

// CASE 3: Status codes (numbers, should be ignored)
export const STATUS_CODES = {
    ok: "200",
    created: "201",
    notFound: "404",
    serverError: "500"
};

// CASE 4: User-facing error messages (SHOULD BE DETECTED)
export const ERROR_MESSAGES = {
    loginFailed: "Invalid username or password",
    sessionExpired: "Your session has expired. Please log in again.",
    networkError: "Unable to connect to the server",
    permissionDenied: "You don't have permission to access this resource",
    invalidInput: "Please check your input and try again"
};

// CASE 5: User-facing success messages (SHOULD BE DETECTED)
export const SUCCESS_MESSAGES = {
    saveSuccess: "Your changes have been saved successfully",
    deleteSuccess: "Item deleted successfully",
    uploadComplete: "File uploaded successfully"
};

// CASE 6: Field labels (SHOULD BE DETECTED)
export const FIELD_LABELS = {
    username: "Username",
    password: "Password",
    email: "Email Address",
    firstName: "First Name",
    lastName: "Last Name",
    phoneNumber: "Phone Number"
};

// CASE 7: Button labels (SHOULD BE DETECTED)
export const BUTTON_LABELS = {
    submit: "Submit",
    cancel: "Cancel",
    save: "Save Changes",
    delete: "Delete",
    edit: "Edit",
    close: "Close",
    confirm: "Confirm"
};

// CASE 8: Placeholder text (SHOULD BE DETECTED)
export const PLACEHOLDERS = {
    searchPlaceholder: "Search products...",
    emailPlaceholder: "Enter your email",
    messagePlaceholder: "Type your message here"
};

// CASE 9: Validation messages (SHOULD BE DETECTED)
export const VALIDATION_MESSAGES = {
    required: "This field is required",
    emailInvalid: "Please enter a valid email address",
    passwordTooShort: "Password must be at least 8 characters",
    passwordMismatch: "Passwords do not match"
};

// CASE 10: Environment variables (technical, but keys might vary)
export const ENV_KEYS = {
    apiUrl: "REACT_APP_API_URL",
    nodeEnv: "NODE_ENV",
    publicUrl: "PUBLIC_URL"
};

// CASE 11: Router paths (technical paths, should be ignored)
export const ROUTES = {
    home: "/",
    dashboard: "/dashboard",
    profile: "/profile",
    settings: "/settings",
    notFound: "/404"
};

// CASE 12: CSS class names (technical, should be ignored)
export const CSS_CLASSES = {
    active: "active",
    disabled: "disabled",
    hidden: "hidden",
    loading: "loading"
};

// CASE 13: Local storage keys (technical identifiers)
export const STORAGE_KEYS = {
    token: "auth_token",
    user: "user_data",
    preferences: "user_preferences"
};

// CASE 14: Regex patterns (should be ignored)
export const PATTERNS = {
    email: "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$",
    phone: "^\\+?[1-9]\\d{1,14}$",
    url: "^https?:\\/\\/.+"
};

// CASE 15: Page titles (SHOULD BE DETECTED)
export const PAGE_TITLES = {
    home: "Home - My Application",
    dashboard: "Dashboard - My Application",
    profile: "User Profile",
    settings: "Account Settings"
};

// CASE 16: Empty states (SHOULD BE DETECTED)
export const EMPTY_STATES = {
    noResults: "No results found",
    noData: "No data available",
    emptyCart: "Your cart is empty",
    noNotifications: "You have no new notifications"
};

// CASE 17: Loading states (SHOULD BE DETECTED)
export const LOADING_MESSAGES = {
    loading: "Loading...",
    pleaseWait: "Please wait",
    processing: "Processing your request"
};

// CASE 18: Date format strings (technical, should be ignored)
export const DATE_FORMATS = {
    short: "MM/DD/YYYY",
    long: "MMMM DD, YYYY",
    time: "HH:mm:ss"
};

// CASE 19: Currency symbols
export const CURRENCIES = {
    usd: "$",
    eur: "€",
    gbp: "£",
    nzd: "NZ$"
};

// CASE 20: Mixed case with localization keys already used
export const MIXED_CONTENT = {
    alreadyLocalized: "user.profile.title",  // This looks like a key
    shouldBeLocalized: "Edit Your Profile"  // This should be detected
};
