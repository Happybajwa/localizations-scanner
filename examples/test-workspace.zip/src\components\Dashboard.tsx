import React from 'react';

export const Dashboard: React.FC = () => {
  return (
    <div>
      {/* 6-level deep nesting - EXISTS */}
      <h1>{t('app.features.analytics.charts.users.active.label')}</h1>
      
      {/* 6-level deep nesting - MISSING */}
      <p>{t('app.features.analytics.charts.users.inactive.label')}</p>
      
      {/* 5-level deep nesting - EXISTS */}
      <h2>{t('app.features.analytics.charts.revenue.title')}</h2>
      
      {/* 5-level deep nesting - MISSING */}
      <p>{t('app.features.analytics.charts.expenses.title')}</p>
      
      {/* 4-level deep nesting - EXISTS */}
      <span>{t('app.navigation.menu.items.dashboard.label')}</span>
      
      {/* 4-level deep nesting - MISSING */}
      <span>{t('app.navigation.menu.items.profile.label')}</span>
      
      {/* Deep nesting with missing intermediate levels */}
      <div>{t('app.features.reports.monthly.sales.summary')}</div>
    </div>
  );
};
