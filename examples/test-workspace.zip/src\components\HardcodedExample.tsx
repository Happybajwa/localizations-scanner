import React from 'react';

// Component with hardcoded strings
export const HardcodedExample = () => {
    const welcomeMessage = "Welcome to our application!";
    const errorMessage = "Something went wrong";

    return (
        <div>
            <h1>Hello World</h1>
            <p>This is a hardcoded paragraph</p>
            <button onClick={() => alert("Button clicked!")}>
                Click me
            </button>
            <span title="This is a tooltip">Hover here</span>
            {welcomeMessage}
            {errorMessage}
        </div>
    );
};

// Styled components example (simulated)
const Title = "Dashboard Title";
const Description = "View your dashboard metrics";

// More hardcoded strings
const messages = {
    success: "Operation completed successfully",
    warning: "Please check your input",
    info: "Additional information available"
};
