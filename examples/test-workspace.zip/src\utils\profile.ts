export const UserProfile = () => {
  // 6-level deep - EXISTS
  const name = t('user.profile.personal.details.basic.name');
  const email = t('user.profile.personal.details.basic.email');
  
  // 6-level deep - MISSING
  const age = t('user.profile.personal.details.basic.age');
  const country = t('user.profile.personal.details.address.country');
  
  // 7-level deep - MISSING (even deeper!)
  const notifSound = t('user.profile.settings.privacy.options.notifications.sound.enabled');
  
  // Mix of existing and missing at various depths
  const street = t('user.profile.personal.details.address.street'); // EXISTS
  const zipcode = t('user.profile.personal.details.address.zipcode'); // MISSING
  
  // Very deep missing key
  const preference = t('user.profile.settings.privacy.options.notifications.email.schedule.daily'); // MISSING
  
  return {
    name,
    email,
    age,
    country,
    notifSound,
    street,
    zipcode,
    preference
  };
};
