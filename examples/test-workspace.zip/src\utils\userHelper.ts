export function getUserLabels() {
  return {
    name: t('user.profile.name'),
    email: t('user.profile.email'),
    phone: t('user.profile.phone'), // This key is MISSING
    address: t('user.contact.address') // This key is MISSING
  };
}

export function getMessages() {
  return {
    greeting: t("welcome.message"),
    error: t('error.message'), // This key is MISSING
    success: t(`success.message`) // This key is MISSING
  };
}
