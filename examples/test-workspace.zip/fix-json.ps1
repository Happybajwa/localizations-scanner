# Fix JSON encoding - removes UTF-8 BOM
$content = Get-Content scan.json -Raw
$utf8NoBom = New-Object System.Text.UTF8Encoding $false
[System.IO.File]::WriteAllText("$PWD\scan.json", $content, $utf8NoBom)

# Validate
try {
    node -e "JSON.parse(require('fs').readFileSync('scan.json', 'utf8')); console.log('✓ Valid JSON');"
    Write-Host "✓ scan.json fixed and validated" -ForegroundColor Green
} catch {
    Write-Host "✗ JSON still invalid" -ForegroundColor Red
}
