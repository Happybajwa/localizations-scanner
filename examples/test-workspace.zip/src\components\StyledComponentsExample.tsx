import React from 'react';

// Simulating styled-components patterns
// Note: Real styled-components would be: styled.div`css here`

// CASE 1: CSS-in-JS with hardcoded strings in content properties
const CardStyles = `
    .card {
        padding: 20px;
        border-radius: 8px;
    }
    .card::before {
        content: "Featured Item";
        font-weight: bold;
    }
    .card::after {
        content: "★";
    }
`;

// CASE 2: Inline styles with values
const inlineStyles = {
    container: {
        backgroundColor: "#f0f0f0",
        padding: "16px",
        margin: "0 auto"
    },
    text: {
        fontSize: "14px",
        fontFamily: "Arial, sans-serif",
        color: "inherit"
    }
};

// CASE 3: Component with data-* and aria-* attributes (should be ignored)
export const AccessibleComponent = () => {
    return (
        <div
            data-component="accessible"
            data-test="integration-test"
            aria-label="Main content area"
            aria-describedby="description"
        >
            <h2>Accessible Title</h2>
            <p id="description">This is the description text</p>
        </div>
    );
};

// CASE 4: Animation keyframes (simulated)
const animations = {
    fadeIn: `
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }
    `,
    slideIn: `
        @keyframes slideIn {
            from { 
                transform: translateX(-100%); 
                content: "Animating...";
            }
            to { 
                transform: translateX(0); 
                content: "Complete";
            }
        }
    `
};

// CASE 5: Media queries with breakpoints
const responsive = {
    mobile: "max-width: 768px",
    tablet: "max-width: 1024px",
    desktop: "min-width: 1025px"
};

// CASE 6: Complex component with multiple string types
export const ComplexStyledComponent = () => {
    const dynamicClass = "active";
    
    return (
        <div 
            className={`container ${dynamicClass}`}
            style={inlineStyles.container}
            data-testid="complex-component"
        >
            {/* Hardcoded heading - should be detected */}
            <h1>Product Showcase</h1>
            
            {/* Hardcoded description - should be detected */}
            <p className="description">
                Discover our latest collection of premium products
            </p>

            {/* Button with hardcoded text - should be detected */}
            <button 
                className="btn-primary"
                aria-label="Shop now button"
                data-action="navigate"
            >
                Shop Now
            </button>

            {/* Price display with hardcoded currency */}
            <div className="price">
                <span className="currency">$</span>
                <span className="amount">299.99</span>
            </div>

            {/* Status badge */}
            <span className="badge">New Arrival</span>
        </div>
    );
};

// CASE 7: Pseudo-element content strings
const pseudoElements = {
    beforeContent: "→",
    afterContent: "•",
    tooltipText: "Hover for more information",
    requiredIndicator: "*"
};

// CASE 8: Grid and flexbox layout strings (technical)
const layoutStyles = {
    display: "grid",
    gridTemplate: "repeat(3, 1fr)",
    flexDirection: "column",
    justifyContent: "space-between",
    alignItems: "center"
};

// CASE 9: Color palette (hexadecimal strings - should be ignored)
const colors = {
    primary: "#007bff",
    secondary: "#6c757d",
    success: "#28a745",
    danger: "#dc3545",
    warning: "#ffc107",
    info: "#17a2b8"
};

// CASE 10: Font definitions
const fonts = {
    heading: "Georgia, serif",
    body: "Helvetica, Arial, sans-serif",
    monospace: "Courier New, monospace",
    fallback: "system-ui"
};

export default ComplexStyledComponent;
