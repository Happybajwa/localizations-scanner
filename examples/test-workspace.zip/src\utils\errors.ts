// Testing extremely deep nesting scenarios

export const ErrorMessages = {
  // 5-level deep - EXISTS
  timeout: t('error.network.timeout.title'),
  
  // 5-level deep - MISSING
  serverError: t('error.network.server.title'),
  
  // 6-level deep - MISSING
  authFailed: t('error.network.auth.failed.message.text'),
  
  // Multiple deep missing keys
  validationErrors: {
    email: t('error.validation.fields.email.format.invalid'),
    password: t('error.validation.fields.password.strength.weak'),
    phone: t('error.validation.fields.phone.format.invalid')
  },
  
  // Navigation deep keys - mix of existing and missing  
  menuLabels: {
    dashboard: t('app.navigation.menu.items.dashboard.label'), // EXISTS
    reports: t('app.navigation.menu.items.reports.label'), // MISSING
    analytics: t('app.navigation.menu.items.analytics.label'), // MISSING
    logout: t('app.navigation.menu.items.logout.label') // MISSING
  }
};
