import React from 'react';

export const Welcome: React.FC = () => {
  return (
    <div>
      <h1>{t('welcome.message')}</h1>
      <h2>{t('welcome.title')}</h2>
      <p>{t('welcome.description')}</p> {/* This key is MISSING */}
    </div>
  );
};
