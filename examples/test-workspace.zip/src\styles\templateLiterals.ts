// Real styled-components syntax using template literals
// This tests if our detector handles template literal patterns

// Simulating: const StyledDiv = styled.div`...`
const Button = `
    padding: 10px 20px;
    background-color: #007bff;
    color: white;
    border: none;
    
    &:hover {
        background-color: #0056b3;
    }
    
    &::before {
        content: "→";
    }
`;

// Simulating emotion/styled-components with nested strings
const Card = `
    .title {
        font-size: 24px;
    }
    .title::after {
        content: "Premium";
    }
    .description {
        opacity: 0.8;
    }
`;

// Template literal with variables (common pattern)
function createStyles(color: string) {
    return `
        background: ${color};
        padding: 16px;
        margin: 8px 0;
    `;
}

// CASE: Template literals with hardcoded text (SHOULD BE DETECTED)
const message = `Welcome to the platform`;
const longMessage = `
    This is a multiline message
    that should be detected as hardcoded
`;

// CASE: Tagged template literals
const sql = `
    SELECT * FROM users 
    WHERE email = 'user@example.com'
    AND status = 'active'
`;

// CASE: Template with only variables (should be ignored)
function formatName(first: string, last: string) {
    return `${first} ${last}`;
}

// CASE: Template with mixed content (SHOULD BE DETECTED)
function greet(name: string) {
    return `Hello ${name}, welcome back!`;
}

// CASE: CSS Grid template areas (technical strings)
const gridLayout = `
    grid-template-areas:
        "header header header"
        "sidebar content content"
        "footer footer footer";
`;

// CASE: Keyframe animation names (technical)
const fadeAnimation = `
    animation: fadeIn 0.3s ease-in;
`;

// CASE: Color values and units (should be ignored)
const theme = `
    --primary-color: #007bff;
    --spacing: 16px;
    --font-size: 1rem;
    --line-height: 1.5;
`;

// CASE: Media query strings (technical)
const breakpoints = `
    @media (max-width: 768px) {
        font-size: 14px;
    }
    @media (min-width: 1024px) {
        font-size: 18px;
    }
`;

// CASE: Transform and transition values (technical)
const transitions = `
    transform: translateX(100%);
    transition: all 0.3s ease;
`;

// CASE: Background images with URLs (should be ignored)
const backgrounds = `
    background-image: url('/images/hero.jpg');
    background-size: cover;
`;

// CASE: Font imports (should be ignored)
const fontImport = `
    @import url('https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap');
`;

export {
    Button,
    Card,
    message,
    longMessage,
    sql,
    greet,
    gridLayout,
    fadeAnimation,
    theme,
    breakpoints,
    transitions,
    backgrounds,
    fontImport
};
