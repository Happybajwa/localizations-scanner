import React from 'react';

// Edge Cases for Hardcoded String Detection

export const EdgeCases = () => {
    // CASE 1: Template literals with variables
    const userName = "John";
    const greeting = `Hello ${userName}!`;
    const multiline = `This is a 
        multiline template literal
        with hardcoded text`;

    // CASE 2: Technical strings that SHOULD BE IGNORED
    const technicalStrings = {
        unit1: "px",
        unit2: "rem",
        unit3: "em",
        unit4: "%",
        display: "flex",
        position: "absolute",
        color: "inherit"
    };

    // CASE 3: URLs and paths that SHOULD BE IGNORED
    const urls = {
        website: "https://example.com",
        api: "http://api.example.com/data",
        relative: "/path/to/resource",
        localPath: "./local/file.txt"
    };

    // CASE 4: Short strings (< 3 chars) that SHOULD BE IGNORED
    const shortStrings = {
        separator: "-",
        space: " ",
        dot: ".",
        ok: "OK"  // This is 2 chars, should be ignored
    };

    // CASE 5: HTTP methods that SHOULD BE IGNORED
    const httpMethods = ["GET", "POST", "PUT", "DELETE", "PATCH"];

    // CASE 6: Strings that SHOULD BE DETECTED
    const userMessages = {
        welcome: "Welcome to the application",
        logout: "You have been logged out",
        sessionExpired: "Your session has expired"
    };

    // CASE 7: Complex JSX with mixed content
    return (
        <div>
            {/* Should be detected */}
            <h1>User Dashboard</h1>
            <p>Manage your account settings here</p>
            
            {/* Technical attributes - should be ignored */}
            <div className="container" id="main-content" data-testid="edge-cases">
                <span aria-label="Help icon">?</span>
            </div>

            {/* Props with hardcoded strings - should be detected */}
            <button title="Save your changes">Save</button>
            <input placeholder="Enter your email address" />
            
            {/* Mixed content */}
            <label>
                First Name
                <input type="text" />
            </label>

            {/* Conditional rendering with hardcoded strings */}
            {true && <p>This condition is always true</p>}
            {false || <span>This fallback text appears</span>}

            {/* String concatenation */}
            <div>{greeting + " Nice to see you!"}</div>
        </div>
    );
};

// CASE 8: Styled components pattern (simulated)
const StyledComponent = {
    Title: `
        font-size: 24px;
        color: blue;
        content: "Hardcoded content in CSS";
    `,
    Button: `
        padding: 10px 20px;
        background: linear-gradient(to right, #ff0000, #00ff00);
    `
};

// CASE 9: Object with deeply nested strings
const config = {
    app: {
        name: "My Application",
        version: "1.0.0",
        description: "This is a comprehensive app description",
        features: {
            auth: {
                loginText: "Sign in to continue",
                logoutText: "Sign out from your account"
            },
            dashboard: {
                emptyState: "No data available to display"
            }
        }
    }
};

// CASE 10: String with special characters and Unicode
const specialStrings = {
    emoji: "Hello 👋 World 🌍",
    symbols: "Price: $99.99 (50% off)",
    unicode: "Café au lait ☕",
    quotes: 'He said "Hello" there',
    escaped: "Line 1\nLine 2\tTabbed"
};

// CASE 11: Console logs (based on config, might be ignored)
console.log("Debugging information");
console.error("An error occurred");
console.warn("This is a warning message");

// CASE 12: Comments (should always be ignored by parser)
// "This is a comment with a string"
/* "This is also a comment" */

// CASE 13: Regex patterns (should be ignored)
const patterns = {
    email: /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/,
    phone: /\+?[0-9]{1,3}?[-. ]?(\([0-9]{3}\)|[0-9]{3})[-. ]?[0-9]{3,4}[-. ]?[0-9]{4}/
};

// CASE 14: Numbers as strings (should be ignored)
const numericStrings = {
    count: "123",
    price: "99.99",
    year: "2024"
};

// CASE 15: Content-type headers (should be ignored)
const headers = {
    contentType: "application/json",
    accept: "text/html"
};

export default EdgeCases;
