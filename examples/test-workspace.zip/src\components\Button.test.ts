// This is a test file that should be IGNORED
export function testButton() {
  const label = t('button.label'); // Should NOT appear in missing keys
  return label;
}
