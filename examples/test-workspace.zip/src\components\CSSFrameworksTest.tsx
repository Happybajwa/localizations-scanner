import React from "react";

/**
 * Test file to verify CSS frameworks (Bootstrap, Tailwind) are properly filtered
 */

export const BootstrapExample: React.FC = () => {
  return (
    <div className="container-fluid p-0 m-0">
      <div className="row">
        <div className="col-md-6 col-lg-4">
          {/* This should be detected - JSX text */}
          <h1>Welcome to our app</h1>

          {/* This should be detected */}
          <p>Please enter your email address</p>

          <div className="btn-group">
            {/* This should be detected */}
            <button className="btn btn-primary">Click here</button>
            <button className="btn btn-secondary">Cancel</button>
          </div>
        </div>

        <div className="col-md-6 col-lg-8">
          {/* This should be detected */}
          <div className="alert alert-warning">
            Important message for the user
          </div>

          <div className="card">
            <div className="card-header">Card Title</div>
            <div className="card-body">
              <p className="card-text">Some descriptive text goes here</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export const TailwindExample: React.FC = () => {
  return (
    <div className="container mx-auto px-4">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <div className="bg-white rounded-lg shadow-md p-6">
          {/* This should be detected - JSX text */}
          <h2 className="text-2xl font-bold mb-4">Product Title</h2>

          {/* This should be detected */}
          <p className="text-gray-600 mb-2">Description of the product</p>

          <div className="flex items-center justify-between mt-4">
            {/* This should be detected */}
            <span className="text-lg font-semibold">$99.99</span>
            <button className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
              Add to Cart
            </button>
          </div>
        </div>

        <div className="bg-gradient-to-r from-purple-500 to-pink-500 p-8">
          {/* This should be detected */}
          <h3 className="text-white text-xl">Special Offer</h3>
          <p className="text-white opacity-90">Limited time only</p>
        </div>

        <div className="border border-gray-300 rounded p-4">
          {/* Responsive utilities */}
          <div className="hidden md:block lg:flex">
            Content visible on larger screens
          </div>

          <div className="sm:w-full md:w-1/2 lg:w-1/3">
            Responsive width container
          </div>
        </div>
      </div>

      {/* Complex utility combinations */}
      <div className="mt-8 space-y-4">
        <div className="flex flex-col sm:flex-row items-center justify-center gap-2">
          <button className="w-full sm:w-auto bg-green-600 hover:bg-green-700 transition-colors duration-200 text-white px-6 py-3 rounded-md">
            Primary Action
          </button>
        </div>
      </div>
    </div>
  );
};

export const MixedExample: React.FC = () => {
  const customClass = "app-custom-component";

  return (
    <div className="container-fluid d-flex justify-content-center align-items-center">
      {/* Mixed Bootstrap + Tailwind (not recommended but can happen) */}
      <div className="card shadow-lg rounded-xl p-6 m-4">
        {/* This should be detected */}
        <h2>User Dashboard</h2>

        {/* This should be detected */}
        <p className="text-muted mb-3">You have 5 new notifications</p>

        {/* Custom classes should be ignored if they're in className */}
        <div className={customClass}>
          <span className="badge bg-danger">Alert</span>
        </div>

        {/* But JSX text should always be detected */}
        <footer className="mt-4 pt-4 border-top">
          © 2026 Company Name. All rights reserved.
        </footer>
      </div>
    </div>
  );
};

// Edge cases
export const EdgeCases: React.FC = () => {
  return (
    <>
      {/* Template literals with classes */}
      <div className={`container ${true ? "active" : ""}`}>
        Dynamic class example
      </div>

      {/* Multiple spaces in className */}
      <div className="d-flex   justify-content-between    align-items-center">
        Multiple spaces test
      </div>

      {/* Single custom class (should be ignored) */}
      <div className="customComponent">Custom component content</div>

      {/* Numbers in JSX text (should be detected) */}
      <div>You have 10 items in your cart</div>

      {/* Mixed content */}
      <button className="btn btn-lg btn-block w-full px-4 py-2 mt-3 mb-2">
        Submit Form
      </button>
    </>
  );
};

// TypeScript and Attribute Edge Cases
import { FC, forwardRef, Dispatch } from 'react';
import { Card, NavDropdown } from 'react-bootstrap';

interface Props {
  filters: string[];
  onUpdate: (filters: string[]) => void;
}

interface RefHandler {
  reset: () => void;
}

export const TypeScriptEdgeCases: React.FC = () => {
  // TypeScript function with Promise/Dispatch types
  // "any" and "void" in type annotations should be IGNORED
  const handleAction = async (dispatch: Dispatch<any>): Promise<void> => {
    console.log('Action dispatched');
  };

  // forwardRef with generic types - FC, Props, RefHandler should be IGNORED
  const MemberFiltersOverlay: FC<Props> = forwardRef<RefHandler, Props>(
    ({ filters, onUpdate }, ref) => {
      return (
        <div>
          <h3>Filters Overlay</h3>
          <p>This text should be detected</p>
        </div>
      );
    }
  );

  return (
    <div>
      {/* Attribute values should be IGNORED - "top", "holder.js/100px180?text=Image cap" */}
      <Card.Img variant="top" src="holder.js/100px180?text=Image cap" />
      
      {/* href values should be IGNORED - "#action/3.1" */}
      <NavDropdown.Item href="#action/3.1">
        Action
      </NavDropdown.Item>
      
      {/* All these attribute values should be IGNORED */}
      <img 
        src="https://example.com/image.jpg" 
        alt="Example image"
        title="This is a tooltip"
        data-testid="test-image"
      />
      
      {/* JSX text SHOULD be detected */}
      <div>
        <h2>Welcome User</h2>
        <p>Your session will expire in 5 minutes</p>
        <button onClick={handleAction}>
          Confirm Action
        </button>
      </div>
      
      {/* Type annotations in JSX should not cause issues */}
      <MemberFiltersOverlay 
        filters={['active', 'pending']} 
        onUpdate={(filters: string[]) => console.log(filters)}
      />
    </div>
  );
};
