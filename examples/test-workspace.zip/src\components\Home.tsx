import React from "react";

export const Home: React.FC = () => {
  const headerText = t("home.header");
  const subtitleText = t("home.subtitle");
  const footerText = t("home.footer"); // This key is MISSING
  const word = "world";
  const textarea = document.createElement("textarea");
  const teamIdFromUrl = searchParams.get("team");
  return (
    <div>
      <header>{headerText}</header>
      <p>{subtitleText}</p>
      <footer>{footerText}</footer>
    </div>
  );
};
